from django.apps import AppConfig


class RecruitingConfig(AppConfig):
    name = 'recruiting'
